var config = {
  development: {
    //url to be used in link generation
    url: "http://www.poker-underdog.com",
    //mongodb connection settings
    database: {
      host: "mongodb://localhost/",
      port: "",
      db: "backend",
    },
    //server details
    server: {
      host: "",
      port: "",
    },
  },
  production: {
    //url to be used in link generation
    url: "mongodb+srv://",
    //mongodb connection settings
    database: {
      user_name: "nadavG",
      port: "",
      db: "myFirstDatabase",
      pass: "DGTkAlmDMGNBJiGw",
    },
    //server details
    server: {
      cluster: "cluster0.kfjyo.mongodb.net",
      port: "",
    },
  },
};
module.exports = config;
